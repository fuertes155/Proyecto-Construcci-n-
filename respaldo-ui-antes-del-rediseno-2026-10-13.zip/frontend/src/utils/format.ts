const cop = new Intl.NumberFormat('es-CO', {
  style: 'currency',
  currency: 'COP',
  maximumFractionDigits: 0,
});

/** Formatea un monto en pesos colombianos: 1165490 → "$ 1.165.490". */
export function formatCOP(value: number | null): string {
  if (value === null) return '—';
  return cop.format(value);
}

/** Formatea una cantidad con hasta 2 decimales, sin ceros de más: 1.50 → "1.5". */
export function formatQty(value: number): string {
  return new Intl.NumberFormat('es-CO', { maximumFractionDigits: 2 }).format(value);
}
