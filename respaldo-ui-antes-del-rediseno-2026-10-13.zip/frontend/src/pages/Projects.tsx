import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useState } from 'react';
import toast from 'react-hot-toast';
import { Link } from 'react-router-dom';
import BudgetSummary from '../components/projects/BudgetSummary';
import ProjectForm from '../components/projects/ProjectForm';
import StatusBadge from '../components/projects/StatusBadge';
import { apiErrorMessage } from '../services/api';
import { projectsApi, type CreateProjectInput } from '../services/projects';

export default function Projects() {
  const [showForm, setShowForm] = useState(false);
  const queryClient = useQueryClient();

  const { data, isLoading, isError } = useQuery({
    queryKey: ['projects'],
    queryFn: projectsApi.list,
  });

  const createMutation = useMutation({
    mutationFn: (input: CreateProjectInput) => projectsApi.create(input),
    onSuccess: () => {
      toast.success('Proyecto creado');
      setShowForm(false);
      queryClient.invalidateQueries({ queryKey: ['projects'] });
    },
    onError: (err) => toast.error(apiErrorMessage(err, 'No se pudo crear el proyecto')),
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Proyectos</h1>
          <p className="mt-2 text-slate-600">Agrupa tus cálculos y sigue el presupuesto de cada obra.</p>
        </div>
        {!showForm && (
          <button type="button" className="btn-primary" onClick={() => setShowForm(true)}>
            Nuevo proyecto
          </button>
        )}
      </div>

      {showForm && (
        <ProjectForm
          submitting={createMutation.isPending}
          onCancel={() => setShowForm(false)}
          onSubmit={(input) => createMutation.mutate(input)}
        />
      )}

      {isLoading && <p className="text-slate-500">Cargando proyectos…</p>}
      {isError && <p className="text-red-600">No se pudieron cargar los proyectos.</p>}

      {data && data.total === 0 && !showForm && (
        <div className="card">
          <p className="text-slate-600">
            Aún no hay proyectos creados. Aquí aparecerán los presupuestos y trabajos activos.
          </p>
        </div>
      )}

      {data && data.total > 0 && (
        <div className="grid gap-4 md:grid-cols-2">
          {data.projects.map((p) => (
            <Link
              key={p.id}
              to={`/projects/${p.id}`}
              className="card block space-y-3 transition hover:shadow-lg"
            >
              <div className="flex items-start justify-between gap-2">
                <div>
                  <h2 className="text-lg font-semibold text-slate-800">{p.name}</h2>
                  {p.location && <p className="text-sm text-slate-500">{p.location}</p>}
                </div>
                <StatusBadge status={p.status} />
              </div>
              <BudgetSummary summary={p.summary} />
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
