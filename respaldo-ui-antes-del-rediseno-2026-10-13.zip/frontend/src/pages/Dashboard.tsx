import { Link } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';

const PROFILE_LABEL: Record<string, string> = {
  owner: 'Propietario',
  contractor: 'Maestro de obra',
  engineer: 'Ingeniero / Arquitecto',
  provider: 'Proveedor',
};

export default function Dashboard() {
  const { user } = useAuth();

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-slate-900">
          Hola, {user?.name?.split(' ')[0] ?? 'bienvenido'}
        </h1>
        <p className="mt-2 text-slate-600">
          Perfil: {PROFILE_LABEL[user?.userType ?? ''] ?? user?.userType} · {user?.email}
        </p>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Link to="/calculators" className="card transition hover:shadow-lg">
          <h2 className="text-xl font-semibold text-slate-800">Calculadoras</h2>
          <p className="mt-2 text-slate-600">
            Calcula hormigón, mampostería y mortero con precios locales de Nariño.
          </p>
        </Link>
        <Link to="/projects" className="card transition hover:shadow-lg">
          <h2 className="text-xl font-semibold text-slate-800">Proyectos</h2>
          <p className="mt-2 text-slate-600">
            Agrupa tus cálculos y sigue el presupuesto frente al objetivo.
          </p>
        </Link>
      </div>

      {user?.role === 'admin' && (
        <div className="card border border-slate-200 bg-slate-50">
          <p className="text-sm text-slate-600">
            Tienes acceso de <strong>administrador</strong>: catálogo de materiales,
            precios por proveedor y moderación de usuarios (API <code>/api/admin/*</code>).
          </p>
        </div>
      )}
    </div>
  );
}
