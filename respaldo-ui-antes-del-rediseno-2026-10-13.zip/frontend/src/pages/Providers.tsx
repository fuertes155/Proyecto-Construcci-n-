export default function Providers() {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-slate-900">Proveedores</h1>
      <div className="card">
        <p className="text-slate-600">Listado de proveedores locales de Nariño y sus precios actualizados.</p>
      </div>
    </div>
  );
}
