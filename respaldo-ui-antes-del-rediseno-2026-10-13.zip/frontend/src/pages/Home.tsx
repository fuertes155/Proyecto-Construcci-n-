import { Link, Navigate } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';

export default function Home() {
  const { user, loading } = useAuth();

  if (!loading && user) return <Navigate to="/dashboard" replace />;

  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-orange-50 to-slate-100 px-4">
      <div className="card max-w-2xl text-center">
        <p className="mb-3 text-sm font-semibold uppercase tracking-[0.2em] text-orange-600">
          ConstruApp Nariño
        </p>
        <h1 className="text-4xl font-bold text-slate-900">Calcula materiales con precisión</h1>
        <p className="mt-4 text-lg text-slate-600">
          Gestiona proyectos, compara precios locales y optimiza tus presupuestos de
          construcción en un solo lugar.
        </p>
        <div className="mt-8 flex justify-center gap-4">
          <Link to="/login" className="btn-primary">
            Iniciar sesión
          </Link>
          <Link to="/register" className="btn-secondary">
            Crear cuenta
          </Link>
        </div>
      </div>
    </div>
  );
}
