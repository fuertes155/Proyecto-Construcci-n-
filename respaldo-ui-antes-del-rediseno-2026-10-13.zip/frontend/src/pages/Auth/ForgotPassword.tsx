import { zodResolver } from '@hookform/resolvers/zod';
import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { Link } from 'react-router-dom';
import { z } from 'zod';
import { api } from '../../services/api';

const schema = z.object({ email: z.string().email('Correo no válido') });
type FormValues = z.infer<typeof schema>;

export default function ForgotPassword() {
  const [sent, setSent] = useState(false);
  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<FormValues>({ resolver: zodResolver(schema) });

  const onSubmit = async (values: FormValues) => {
    try {
      await api.post('/auth/forgot-password', values);
    } catch {
      /* la respuesta es siempre 204; ignoramos cualquier fallo de red silenciosamente */
    }
    setSent(true);
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-slate-100 px-4">
      <div className="card w-full max-w-md">
        <h1 className="text-2xl font-bold text-slate-900">Recuperar contraseña</h1>

        {sent ? (
          <p className="mt-4 text-slate-600">
            Si el correo está registrado, te enviamos un enlace para elegir una nueva
            contraseña. Revisa tu bandeja de entrada.
          </p>
        ) : (
          <>
            <p className="mt-1 text-sm text-slate-500">
              Te enviaremos un enlace para restablecerla.
            </p>
            <form className="mt-6 space-y-4" onSubmit={handleSubmit(onSubmit)} noValidate>
              <div>
                <label className="mb-2 block text-sm font-medium text-slate-700" htmlFor="email">
                  Correo
                </label>
                <input
                  id="email"
                  className="input-field"
                  type="email"
                  autoComplete="email"
                  {...register('email')}
                />
                {errors.email && (
                  <p className="mt-1 text-sm text-red-600">{errors.email.message}</p>
                )}
              </div>
              <button type="submit" className="btn-primary w-full" disabled={isSubmitting}>
                {isSubmitting ? 'Enviando…' : 'Enviar enlace'}
              </button>
            </form>
          </>
        )}

        <p className="mt-4 text-center text-sm text-slate-600">
          <Link to="/login" className="font-medium text-orange-600 hover:underline">
            Volver a iniciar sesión
          </Link>
        </p>
      </div>
    </div>
  );
}
