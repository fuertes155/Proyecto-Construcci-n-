import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useState } from 'react';
import toast from 'react-hot-toast';
import { Link, Navigate, useNavigate, useParams } from 'react-router-dom';
import BudgetSummary from '../components/projects/BudgetSummary';
import EditProjectForm from '../components/projects/EditProjectForm';
import StatusBadge from '../components/projects/StatusBadge';
import { apiErrorMessage } from '../services/api';
import { projectsApi, type ProjectStatus } from '../services/projects';
import { formatCOP, formatQty } from '../utils/format';

const CALCULATOR_LABEL: Record<string, string> = {
  concrete: 'Hormigón',
  brick: 'Mampostería',
  mortar: 'Mortero',
};

const STATUS_OPTIONS: { value: ProjectStatus; label: string }[] = [
  { value: 'planning', label: 'Planificación' },
  { value: 'in-progress', label: 'En progreso' },
  { value: 'finished', label: 'Finalizado' },
];

export default function ProjectDetail() {
  const { projectId } = useParams<{ projectId: string }>();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [editing, setEditing] = useState(false);

  const { data: project, isLoading, isError } = useQuery({
    queryKey: ['projects', projectId],
    queryFn: () => projectsApi.get(projectId!),
    enabled: !!projectId,
  });

  const invalidate = () => {
    queryClient.invalidateQueries({ queryKey: ['projects'] });
    queryClient.invalidateQueries({ queryKey: ['projects', projectId] });
  };

  const updateMutation = useMutation({
    mutationFn: (changes: Parameters<typeof projectsApi.update>[1]) =>
      projectsApi.update(projectId!, changes),
    onSuccess: () => {
      toast.success('Proyecto actualizado');
      setEditing(false);
      invalidate();
    },
    onError: (err) => toast.error(apiErrorMessage(err, 'No se pudo actualizar el proyecto')),
  });

  const deleteMutation = useMutation({
    mutationFn: () => projectsApi.remove(projectId!),
    onSuccess: () => {
      toast.success('Proyecto eliminado');
      // refetchType: 'none' evita que esta misma página (aún montada) vuelva a pedir
      // el detalle del proyecto que se acaba de borrar antes de que navigate() la desmonte.
      queryClient.invalidateQueries({ queryKey: ['projects'], refetchType: 'none' });
      navigate('/projects', { replace: true });
    },
    onError: (err) => toast.error(apiErrorMessage(err, 'No se pudo eliminar el proyecto')),
  });

  const removeCalcMutation = useMutation({
    mutationFn: (calculationId: string) => projectsApi.removeCalculation(projectId!, calculationId),
    onSuccess: () => {
      toast.success('Cálculo eliminado');
      invalidate();
    },
    onError: (err) => toast.error(apiErrorMessage(err, 'No se pudo eliminar el cálculo')),
  });

  if (!projectId) return <Navigate to="/projects" replace />;
  if (isLoading) return <p className="text-slate-500">Cargando proyecto…</p>;
  if (isError || !project) {
    return (
      <div className="card">
        <p className="text-slate-600">
          No se encontró el proyecto o no tienes acceso.{' '}
          <Link to="/projects" className="text-orange-600 hover:underline">
            Volver a proyectos
          </Link>
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <Link to="/projects" className="text-sm text-slate-500 hover:underline">
        ← Proyectos
      </Link>

      {editing ? (
        <EditProjectForm
          project={project}
          submitting={updateMutation.isPending}
          onCancel={() => setEditing(false)}
          onSubmit={(changes) => updateMutation.mutate(changes)}
        />
      ) : (
        <div className="card space-y-4">
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <h1 className="text-2xl font-bold text-slate-900">{project.name}</h1>
              {project.location && <p className="text-slate-500">{project.location}</p>}
            </div>
            <div className="flex items-center gap-2">
              <select
                className="input-field w-auto py-1.5 text-sm"
                value={project.status}
                onChange={(e) =>
                  updateMutation.mutate({ status: e.target.value as ProjectStatus })
                }
              >
                {STATUS_OPTIONS.map((o) => (
                  <option key={o.value} value={o.value}>
                    {o.label}
                  </option>
                ))}
              </select>
              <StatusBadge status={project.status} />
            </div>
          </div>

          {project.description && <p className="text-slate-600">{project.description}</p>}

          <BudgetSummary summary={project.summary} />

          <div className="flex gap-3 border-t border-slate-200 pt-4">
            <button type="button" className="btn-secondary" onClick={() => setEditing(true)}>
              Editar
            </button>
            <button
              type="button"
              className="rounded-md px-4 py-2 text-sm font-medium text-red-600 hover:bg-red-50"
              disabled={deleteMutation.isPending}
              onClick={() => {
                if (window.confirm(`¿Eliminar "${project.name}" y todos sus cálculos?`)) {
                  deleteMutation.mutate();
                }
              }}
            >
              Eliminar proyecto
            </button>
          </div>
        </div>
      )}

      <div className="card">
        <h2 className="mb-4 text-xl font-semibold text-slate-800">
          Cálculos ({project.calculations.length})
        </h2>
        {project.calculations.length === 0 ? (
          <p className="text-slate-500">
            Aún no hay cálculos. Ve a{' '}
            <Link to="/calculators" className="text-orange-600 hover:underline">
              Calculadoras
            </Link>{' '}
            y guarda uno en este proyecto.
          </p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead>
                <tr className="border-b border-slate-200 text-slate-500">
                  <th className="py-2 pr-4">Tipo</th>
                  <th className="py-2 pr-4">Cantidad</th>
                  <th className="py-2 pr-4">Costo</th>
                  <th className="py-2 pr-4">Fecha</th>
                  <th className="py-2" />
                </tr>
              </thead>
              <tbody>
                {project.calculations.map((c) => (
                  <tr key={c.id} className="border-b border-slate-100 last:border-0">
                    <td className="py-2 pr-4 font-medium text-slate-800">
                      {CALCULATOR_LABEL[c.calculatorType] ?? c.calculatorType}
                    </td>
                    <td className="py-2 pr-4">
                      {formatQty(c.quantity)} {c.unit}
                    </td>
                    <td className="py-2 pr-4">{formatCOP(c.totalCost)}</td>
                    <td className="py-2 pr-4 text-slate-500">
                      {new Date(c.createdAt).toLocaleDateString('es-CO')}
                    </td>
                    <td className="py-2 text-right">
                      <button
                        type="button"
                        className="text-red-600 hover:underline"
                        disabled={removeCalcMutation.isPending}
                        onClick={() => removeCalcMutation.mutate(c.id)}
                      >
                        Eliminar
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
