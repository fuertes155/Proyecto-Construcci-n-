import { zodResolver } from '@hookform/resolvers/zod';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Fragment, useState } from 'react';
import { useForm } from 'react-hook-form';
import toast from 'react-hot-toast';
import { z } from 'zod';
import { adminApi, type AdminProvider, type CreateProviderInput } from '../../services/admin';
import { apiErrorMessage } from '../../services/api';

const schema = z.object({
  name: z.string().trim().min(2, 'Ingresa un nombre').max(160),
  location: z.string().trim().max(160).optional().or(z.literal('')),
  phone: z.string().trim().max(40).optional().or(z.literal('')),
  email: z.string().trim().email('Correo inválido').max(160).optional().or(z.literal('')),
  rating: z.coerce.number().min(0).max(5).optional().or(z.literal('')),
  deliveryTime: z.string().trim().max(60).optional().or(z.literal('')),
});
type FormValues = z.infer<typeof schema>;

function ProviderForm({
  initial,
  submitting,
  onSubmit,
  onCancel,
}: {
  initial?: AdminProvider;
  submitting: boolean;
  onSubmit: (input: CreateProviderInput) => void;
  onCancel: () => void;
}) {
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: initial
      ? {
          name: initial.name,
          location: initial.location,
          phone: initial.phone ?? '',
          email: initial.email ?? '',
          rating: initial.rating,
          deliveryTime: initial.deliveryTime ?? '',
        }
      : undefined,
  });

  const submit = (values: FormValues) => {
    onSubmit({
      name: values.name,
      location: values.location || undefined,
      phone: values.phone || undefined,
      email: values.email || undefined,
      rating: values.rating === '' || values.rating === undefined ? undefined : Number(values.rating),
      deliveryTime: values.deliveryTime || undefined,
    });
  };

  return (
    <form className="card grid gap-4 sm:grid-cols-2" onSubmit={handleSubmit(submit)} noValidate>
      <div>
        <label className="mb-1 block text-sm font-medium text-slate-700" htmlFor="prov-name">
          Nombre
        </label>
        <input id="prov-name" className="input-field" {...register('name')} />
        {errors.name && <p className="mt-1 text-sm text-red-600">{errors.name.message}</p>}
      </div>
      <div>
        <label className="mb-1 block text-sm font-medium text-slate-700" htmlFor="prov-location">
          Ubicación
        </label>
        <input id="prov-location" className="input-field" placeholder="Pasto, Nariño" {...register('location')} />
      </div>
      <div>
        <label className="mb-1 block text-sm font-medium text-slate-700" htmlFor="prov-phone">
          Teléfono
        </label>
        <input id="prov-phone" className="input-field" {...register('phone')} />
      </div>
      <div>
        <label className="mb-1 block text-sm font-medium text-slate-700" htmlFor="prov-email">
          Correo
        </label>
        <input id="prov-email" type="email" className="input-field" {...register('email')} />
        {errors.email && <p className="mt-1 text-sm text-red-600">{errors.email.message}</p>}
      </div>
      <div>
        <label className="mb-1 block text-sm font-medium text-slate-700" htmlFor="prov-rating">
          Calificación (0-5)
        </label>
        <input id="prov-rating" type="number" step="0.1" min="0" max="5" className="input-field" {...register('rating')} />
        {errors.rating && <p className="mt-1 text-sm text-red-600">{errors.rating.message}</p>}
      </div>
      <div>
        <label className="mb-1 block text-sm font-medium text-slate-700" htmlFor="prov-delivery">
          Tiempo de entrega
        </label>
        <input id="prov-delivery" className="input-field" placeholder="24-48 horas" {...register('deliveryTime')} />
      </div>
      <div className="flex gap-3 sm:col-span-2">
        <button type="submit" className="btn-primary" disabled={submitting}>
          {submitting ? 'Guardando…' : initial ? 'Guardar cambios' : 'Crear proveedor'}
        </button>
        <button type="button" className="btn-secondary" onClick={onCancel}>
          Cancelar
        </button>
      </div>
    </form>
  );
}

export default function AdminProviders() {
  const [showCreate, setShowCreate] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const queryClient = useQueryClient();

  const { data: providers, isLoading, isError } = useQuery({
    queryKey: ['admin', 'providers'],
    queryFn: adminApi.providers.list,
  });

  const invalidate = () => queryClient.invalidateQueries({ queryKey: ['admin', 'providers'] });

  const createMutation = useMutation({
    mutationFn: adminApi.providers.create,
    onSuccess: () => {
      toast.success('Proveedor creado');
      setShowCreate(false);
      invalidate();
    },
    onError: (err) => toast.error(apiErrorMessage(err, 'No se pudo crear el proveedor')),
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, changes }: { id: string; changes: Partial<CreateProviderInput> }) =>
      adminApi.providers.update(id, changes),
    onSuccess: () => {
      toast.success('Proveedor actualizado');
      setEditingId(null);
      invalidate();
    },
    onError: (err) => toast.error(apiErrorMessage(err, 'No se pudo actualizar el proveedor')),
  });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-semibold text-slate-800">Proveedores</h2>
        {!showCreate && (
          <button type="button" className="btn-primary" onClick={() => setShowCreate(true)}>
            Nuevo proveedor
          </button>
        )}
      </div>

      {showCreate && (
        <ProviderForm
          submitting={createMutation.isPending}
          onCancel={() => setShowCreate(false)}
          onSubmit={(input) => createMutation.mutate(input)}
        />
      )}

      {isLoading && <p className="text-slate-500">Cargando proveedores…</p>}
      {isError && <p className="text-red-600">No se pudieron cargar los proveedores.</p>}

      {providers && (
        <div className="card overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead>
              <tr className="border-b border-slate-200 text-slate-500">
                <th className="py-2 pr-4">Nombre</th>
                <th className="py-2 pr-4">Ubicación</th>
                <th className="py-2 pr-4">Contacto</th>
                <th className="py-2 pr-4">Calificación</th>
                <th className="py-2 pr-4">Entrega</th>
                <th className="py-2" />
              </tr>
            </thead>
            <tbody>
              {providers.map((p) => (
                <Fragment key={p.id}>
                  <tr className="border-b border-slate-100 last:border-0">
                    <td className="py-2 pr-4 font-medium text-slate-800">{p.name}</td>
                    <td className="py-2 pr-4 text-slate-500">{p.location}</td>
                    <td className="py-2 pr-4 text-slate-500">
                      {p.phone ?? '—'}
                      {p.email ? ` · ${p.email}` : ''}
                    </td>
                    <td className="py-2 pr-4">{p.rating.toFixed(1)}</td>
                    <td className="py-2 pr-4 text-slate-500">{p.deliveryTime ?? '—'}</td>
                    <td className="py-2 text-right">
                      <button
                        type="button"
                        className="text-orange-600 hover:underline"
                        onClick={() => setEditingId(editingId === p.id ? null : p.id)}
                      >
                        {editingId === p.id ? 'Cerrar' : 'Editar'}
                      </button>
                    </td>
                  </tr>
                  {editingId === p.id && (
                    <tr>
                      <td colSpan={6} className="pb-4">
                        <ProviderForm
                          initial={p}
                          submitting={updateMutation.isPending}
                          onCancel={() => setEditingId(null)}
                          onSubmit={(changes) => updateMutation.mutate({ id: p.id, changes })}
                        />
                      </td>
                    </tr>
                  )}
                </Fragment>
              ))}
              {providers.length === 0 && (
                <tr>
                  <td colSpan={6} className="py-4 text-slate-500">
                    Aún no hay proveedores registrados.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
