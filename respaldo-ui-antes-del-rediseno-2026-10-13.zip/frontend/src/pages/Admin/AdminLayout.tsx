import { NavLink, Outlet } from 'react-router-dom';

const tabs = [
  { to: '/admin/materials', label: 'Materiales' },
  { to: '/admin/prices', label: 'Precios' },
  { to: '/admin/providers', label: 'Proveedores' },
  { to: '/admin/users', label: 'Usuarios' },
];

export default function AdminLayout() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-slate-900">Administración</h1>
        <p className="mt-2 text-slate-600">
          Catálogo de materiales, precios por proveedor y moderación de usuarios.
        </p>
      </div>

      <nav className="flex flex-wrap gap-2 border-b border-slate-200 pb-2">
        {tabs.map((tab) => (
          <NavLink
            key={tab.to}
            to={tab.to}
            className={({ isActive }) =>
              `rounded-md px-3 py-2 text-sm font-medium transition ${
                isActive ? 'bg-orange-100 text-orange-700' : 'text-slate-700 hover:bg-slate-100'
              }`
            }
          >
            {tab.label}
          </NavLink>
        ))}
      </nav>

      <Outlet />
    </div>
  );
}
