import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useEffect, useState } from 'react';
import toast from 'react-hot-toast';
import { adminApi } from '../../services/admin';
import { apiErrorMessage } from '../../services/api';
import { useAuth } from '../../hooks/useAuth';

export default function AdminUsers() {
  const { user: me } = useAuth();
  const [status, setStatus] = useState('');
  const [role, setRole] = useState('');
  const [q, setQ] = useState('');
  const [debouncedQ, setDebouncedQ] = useState('');
  const queryClient = useQueryClient();

  // Evita disparar una petición por cada tecla escrita en el buscador.
  useEffect(() => {
    const id = setTimeout(() => setDebouncedQ(q), 300);
    return () => clearTimeout(id);
  }, [q]);

  const { data, isLoading, isError } = useQuery({
    queryKey: ['admin', 'users', status, role, debouncedQ],
    queryFn: () =>
      adminApi.users.list({
        status: status || undefined,
        role: role || undefined,
        q: debouncedQ || undefined,
      }),
  });

  const statusMutation = useMutation({
    mutationFn: ({ id, next }: { id: string; next: 'active' | 'suspended' }) =>
      adminApi.users.setStatus(id, next),
    onSuccess: () => {
      toast.success('Estado actualizado');
      queryClient.invalidateQueries({ queryKey: ['admin', 'users'] });
    },
    onError: (err) => toast.error(apiErrorMessage(err, 'No se pudo actualizar el estado')),
  });

  return (
    <div className="space-y-6">
      <h2 className="text-xl font-semibold text-slate-800">Usuarios</h2>

      <div className="flex flex-wrap gap-3">
        <input
          className="input-field w-auto"
          placeholder="Buscar por correo o nombre…"
          value={q}
          onChange={(e) => setQ(e.target.value)}
        />
        <select className="input-field w-auto" value={status} onChange={(e) => setStatus(e.target.value)}>
          <option value="">Todos los estados</option>
          <option value="active">Activo</option>
          <option value="suspended">Suspendido</option>
        </select>
        <select className="input-field w-auto" value={role} onChange={(e) => setRole(e.target.value)}>
          <option value="">Todos los roles</option>
          <option value="user">Usuario</option>
          <option value="provider">Proveedor</option>
          <option value="admin">Admin</option>
        </select>
      </div>

      {isLoading && <p className="text-slate-500">Cargando usuarios…</p>}
      {isError && <p className="text-red-600">No se pudieron cargar los usuarios.</p>}

      {data && (
        <div className="card overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead>
              <tr className="border-b border-slate-200 text-slate-500">
                <th className="py-2 pr-4">Nombre</th>
                <th className="py-2 pr-4">Correo</th>
                <th className="py-2 pr-4">Tipo</th>
                <th className="py-2 pr-4">Rol</th>
                <th className="py-2 pr-4">Estado</th>
                <th className="py-2" />
              </tr>
            </thead>
            <tbody>
              {data.users.map((u) => (
                <tr key={u.id} className="border-b border-slate-100 last:border-0">
                  <td className="py-2 pr-4 font-medium text-slate-800">
                    {[u.firstName, u.lastName].filter(Boolean).join(' ')}
                  </td>
                  <td className="py-2 pr-4 text-slate-500">{u.email}</td>
                  <td className="py-2 pr-4 text-slate-500">{u.userType}</td>
                  <td className="py-2 pr-4 text-slate-500">{u.role}</td>
                  <td className="py-2 pr-4">
                    <span
                      className={`rounded px-2 py-0.5 text-xs font-medium ${
                        u.status === 'active' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'
                      }`}
                    >
                      {u.status === 'active' ? 'Activo' : 'Suspendido'}
                    </span>
                  </td>
                  <td className="py-2 text-right">
                    {u.id === me?.id ? (
                      <span className="text-slate-400">Tu cuenta</span>
                    ) : (
                      <button
                        type="button"
                        className={u.status === 'active' ? 'text-red-600 hover:underline' : 'text-green-700 hover:underline'}
                        disabled={statusMutation.isPending}
                        onClick={() =>
                          statusMutation.mutate({
                            id: u.id,
                            next: u.status === 'active' ? 'suspended' : 'active',
                          })
                        }
                      >
                        {u.status === 'active' ? 'Suspender' : 'Reactivar'}
                      </button>
                    )}
                  </td>
                </tr>
              ))}
              {data.users.length === 0 && (
                <tr>
                  <td colSpan={6} className="py-4 text-slate-500">
                    No hay usuarios con este filtro.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
