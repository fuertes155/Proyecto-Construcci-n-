import { zodResolver } from '@hookform/resolvers/zod';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Fragment, useState } from 'react';
import { useForm } from 'react-hook-form';
import toast from 'react-hot-toast';
import { z } from 'zod';
import { adminApi, type AdminMaterial, type CreateMaterialInput } from '../../services/admin';
import { apiErrorMessage } from '../../services/api';

const schema = z.object({
  name: z.string().trim().min(2, 'Ingresa un nombre').max(160),
  unit: z.string().trim().min(1, 'Ingresa la unidad').max(40),
  category: z.string().trim().max(60).optional().or(z.literal('')),
  description: z.string().trim().max(1000).optional().or(z.literal('')),
});
type FormValues = z.infer<typeof schema>;

function MaterialForm({
  initial,
  submitting,
  onSubmit,
  onCancel,
}: {
  initial?: AdminMaterial;
  submitting: boolean;
  onSubmit: (input: CreateMaterialInput) => void;
  onCancel: () => void;
}) {
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: initial
      ? {
          name: initial.name,
          unit: initial.unit,
          category: initial.category ?? '',
          description: initial.description ?? '',
        }
      : undefined,
  });

  const submit = (values: FormValues) => {
    onSubmit({
      name: values.name,
      unit: values.unit,
      category: values.category || undefined,
      description: values.description || undefined,
    });
  };

  return (
    <form className="card grid gap-4 sm:grid-cols-2" onSubmit={handleSubmit(submit)} noValidate>
      <div>
        <label className="mb-1 block text-sm font-medium text-slate-700" htmlFor="mat-name">
          Nombre
        </label>
        <input id="mat-name" className="input-field" {...register('name')} />
        {errors.name && <p className="mt-1 text-sm text-red-600">{errors.name.message}</p>}
      </div>
      <div>
        <label className="mb-1 block text-sm font-medium text-slate-700" htmlFor="mat-unit">
          Unidad
        </label>
        <input id="mat-unit" className="input-field" placeholder="saco 50 kg, m³, unidad…" {...register('unit')} />
        {errors.unit && <p className="mt-1 text-sm text-red-600">{errors.unit.message}</p>}
      </div>
      <div>
        <label className="mb-1 block text-sm font-medium text-slate-700" htmlFor="mat-category">
          Categoría
        </label>
        <input id="mat-category" className="input-field" {...register('category')} />
      </div>
      <div className="sm:col-span-2">
        <label className="mb-1 block text-sm font-medium text-slate-700" htmlFor="mat-description">
          Descripción
        </label>
        <textarea id="mat-description" className="input-field" rows={2} {...register('description')} />
      </div>
      <div className="flex gap-3 sm:col-span-2">
        <button type="submit" className="btn-primary" disabled={submitting}>
          {submitting ? 'Guardando…' : initial ? 'Guardar cambios' : 'Crear material'}
        </button>
        <button type="button" className="btn-secondary" onClick={onCancel}>
          Cancelar
        </button>
      </div>
    </form>
  );
}

export default function AdminMaterials() {
  const [showCreate, setShowCreate] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const queryClient = useQueryClient();

  const { data: materials, isLoading, isError } = useQuery({
    queryKey: ['admin', 'materials'],
    queryFn: adminApi.materials.list,
  });

  const invalidate = () => queryClient.invalidateQueries({ queryKey: ['admin', 'materials'] });

  const createMutation = useMutation({
    mutationFn: adminApi.materials.create,
    onSuccess: () => {
      toast.success('Material creado');
      setShowCreate(false);
      invalidate();
    },
    onError: (err) => toast.error(apiErrorMessage(err, 'No se pudo crear el material')),
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, changes }: { id: string; changes: Partial<CreateMaterialInput> }) =>
      adminApi.materials.update(id, changes),
    onSuccess: () => {
      toast.success('Material actualizado');
      setEditingId(null);
      invalidate();
    },
    onError: (err) => toast.error(apiErrorMessage(err, 'No se pudo actualizar el material')),
  });

  const toggleActiveMutation = useMutation({
    mutationFn: ({ id, active }: { id: string; active: boolean }) =>
      active ? adminApi.materials.reactivate(id) : adminApi.materials.deactivate(id),
    onSuccess: () => {
      toast.success('Estado actualizado');
      invalidate();
    },
    onError: (err) => toast.error(apiErrorMessage(err, 'No se pudo cambiar el estado')),
  });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-semibold text-slate-800">Catálogo de materiales</h2>
        {!showCreate && (
          <button type="button" className="btn-primary" onClick={() => setShowCreate(true)}>
            Nuevo material
          </button>
        )}
      </div>

      {showCreate && (
        <MaterialForm
          submitting={createMutation.isPending}
          onCancel={() => setShowCreate(false)}
          onSubmit={(input) => createMutation.mutate(input)}
        />
      )}

      {isLoading && <p className="text-slate-500">Cargando materiales…</p>}
      {isError && <p className="text-red-600">No se pudo cargar el catálogo.</p>}

      {materials && (
        <div className="card overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead>
              <tr className="border-b border-slate-200 text-slate-500">
                <th className="py-2 pr-4">Nombre</th>
                <th className="py-2 pr-4">Unidad</th>
                <th className="py-2 pr-4">Categoría</th>
                <th className="py-2 pr-4">Estado</th>
                <th className="py-2" />
              </tr>
            </thead>
            <tbody>
              {materials.map((m) => (
                <Fragment key={m.id}>
                  <tr className="border-b border-slate-100 last:border-0">
                    <td className="py-2 pr-4 font-medium text-slate-800">{m.name}</td>
                    <td className="py-2 pr-4">{m.unit}</td>
                    <td className="py-2 pr-4 text-slate-500">{m.category ?? '—'}</td>
                    <td className="py-2 pr-4">
                      <span
                        className={`rounded px-2 py-0.5 text-xs font-medium ${
                          m.active ? 'bg-green-100 text-green-700' : 'bg-slate-200 text-slate-600'
                        }`}
                      >
                        {m.active ? 'Activo' : 'Inactivo'}
                      </span>
                    </td>
                    <td className="py-2 text-right">
                      <div className="flex justify-end gap-3">
                        <button
                          type="button"
                          className="text-orange-600 hover:underline"
                          onClick={() => setEditingId(editingId === m.id ? null : m.id)}
                        >
                          {editingId === m.id ? 'Cerrar' : 'Editar'}
                        </button>
                        <button
                          type="button"
                          className="text-red-600 hover:underline"
                          disabled={toggleActiveMutation.isPending}
                          onClick={() =>
                            toggleActiveMutation.mutate({ id: m.id, active: !m.active })
                          }
                        >
                          {m.active ? 'Desactivar' : 'Reactivar'}
                        </button>
                      </div>
                    </td>
                  </tr>
                  {editingId === m.id && (
                    <tr>
                      <td colSpan={5} className="pb-4">
                        <MaterialForm
                          initial={m}
                          submitting={updateMutation.isPending}
                          onCancel={() => setEditingId(null)}
                          onSubmit={(changes) => updateMutation.mutate({ id: m.id, changes })}
                        />
                      </td>
                    </tr>
                  )}
                </Fragment>
              ))}
              {materials.length === 0 && (
                <tr>
                  <td colSpan={5} className="py-4 text-slate-500">
                    Aún no hay materiales en el catálogo.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
