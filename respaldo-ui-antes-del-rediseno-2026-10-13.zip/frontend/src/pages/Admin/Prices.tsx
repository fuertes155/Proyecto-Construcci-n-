import { zodResolver } from '@hookform/resolvers/zod';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useState } from 'react';
import { useForm } from 'react-hook-form';
import toast from 'react-hot-toast';
import { z } from 'zod';
import { adminApi } from '../../services/admin';
import { apiErrorMessage } from '../../services/api';
import { formatCOP } from '../../utils/format';

const schema = z.object({
  materialId: z.string().uuid('Selecciona un material'),
  providerId: z.string().uuid('Selecciona un proveedor'),
  price: z.coerce.number().positive('Debe ser mayor a 0'),
});
type FormValues = z.infer<typeof schema>;

export default function AdminPrices() {
  const [filterMaterial, setFilterMaterial] = useState('');
  const [filterProvider, setFilterProvider] = useState('');
  const queryClient = useQueryClient();

  const { data: materials } = useQuery({
    queryKey: ['admin', 'materials'],
    queryFn: adminApi.materials.list,
  });
  const { data: providers } = useQuery({
    queryKey: ['admin', 'providers'],
    queryFn: adminApi.providers.list,
  });
  const { data: prices, isLoading, isError } = useQuery({
    queryKey: ['admin', 'prices', filterMaterial, filterProvider],
    queryFn: () =>
      adminApi.prices.list({
        materialId: filterMaterial || undefined,
        providerId: filterProvider || undefined,
      }),
  });

  const invalidatePrices = () =>
    queryClient.invalidateQueries({ queryKey: ['admin', 'prices'] });

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<FormValues>({ resolver: zodResolver(schema) });

  const upsertMutation = useMutation({
    mutationFn: adminApi.prices.upsert,
    onSuccess: () => {
      toast.success('Precio guardado');
      reset({ materialId: '', providerId: '', price: undefined });
      invalidatePrices();
    },
    onError: (err) => toast.error(apiErrorMessage(err, 'No se pudo guardar el precio')),
  });

  const removeMutation = useMutation({
    mutationFn: adminApi.prices.remove,
    onSuccess: () => {
      toast.success('Precio eliminado');
      invalidatePrices();
    },
    onError: (err) => toast.error(apiErrorMessage(err, 'No se pudo eliminar el precio')),
  });

  return (
    <div className="space-y-6">
      <h2 className="text-xl font-semibold text-slate-800">Precios por proveedor</h2>

      <form
        className="card grid gap-4 sm:grid-cols-4"
        onSubmit={handleSubmit((values) => upsertMutation.mutate(values))}
        noValidate
      >
        <div>
          <label className="mb-1 block text-sm font-medium text-slate-700" htmlFor="price-material">
            Material
          </label>
          <select id="price-material" className="input-field" {...register('materialId')}>
            <option value="">Selecciona…</option>
            {materials?.map((m) => (
              <option key={m.id} value={m.id}>
                {m.name}
              </option>
            ))}
          </select>
          {errors.materialId && <p className="mt-1 text-sm text-red-600">{errors.materialId.message}</p>}
        </div>
        <div>
          <label className="mb-1 block text-sm font-medium text-slate-700" htmlFor="price-provider">
            Proveedor
          </label>
          <select id="price-provider" className="input-field" {...register('providerId')}>
            <option value="">Selecciona…</option>
            {providers?.map((p) => (
              <option key={p.id} value={p.id}>
                {p.name}
              </option>
            ))}
          </select>
          {errors.providerId && <p className="mt-1 text-sm text-red-600">{errors.providerId.message}</p>}
        </div>
        <div>
          <label className="mb-1 block text-sm font-medium text-slate-700" htmlFor="price-value">
            Precio (COP)
          </label>
          <input id="price-value" type="number" step="any" className="input-field" {...register('price')} />
          {errors.price && <p className="mt-1 text-sm text-red-600">{errors.price.message}</p>}
        </div>
        <div className="flex items-end">
          <button type="submit" className="btn-primary w-full" disabled={upsertMutation.isPending}>
            {upsertMutation.isPending ? 'Guardando…' : 'Guardar precio'}
          </button>
        </div>
      </form>

      <div className="flex flex-wrap gap-3">
        <select
          className="input-field w-auto"
          value={filterMaterial}
          onChange={(e) => setFilterMaterial(e.target.value)}
        >
          <option value="">Todos los materiales</option>
          {materials?.map((m) => (
            <option key={m.id} value={m.id}>
              {m.name}
            </option>
          ))}
        </select>
        <select
          className="input-field w-auto"
          value={filterProvider}
          onChange={(e) => setFilterProvider(e.target.value)}
        >
          <option value="">Todos los proveedores</option>
          {providers?.map((p) => (
            <option key={p.id} value={p.id}>
              {p.name}
            </option>
          ))}
        </select>
      </div>

      {isLoading && <p className="text-slate-500">Cargando precios…</p>}
      {isError && <p className="text-red-600">No se pudieron cargar los precios.</p>}

      {prices && (
        <div className="card overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead>
              <tr className="border-b border-slate-200 text-slate-500">
                <th className="py-2 pr-4">Material</th>
                <th className="py-2 pr-4">Proveedor</th>
                <th className="py-2 pr-4">Precio</th>
                <th className="py-2 pr-4">Actualizado</th>
                <th className="py-2" />
              </tr>
            </thead>
            <tbody>
              {prices.map((p) => (
                <tr key={p.id} className="border-b border-slate-100 last:border-0">
                  <td className="py-2 pr-4 font-medium text-slate-800">
                    {p.material.name} <span className="text-slate-400">({p.material.unit})</span>
                  </td>
                  <td className="py-2 pr-4">{p.provider.name}</td>
                  <td className="py-2 pr-4">{formatCOP(p.price)}</td>
                  <td className="py-2 pr-4 text-slate-500">
                    {new Date(p.updatedAt).toLocaleDateString('es-CO')}
                  </td>
                  <td className="py-2 text-right">
                    <button
                      type="button"
                      className="text-red-600 hover:underline"
                      disabled={removeMutation.isPending}
                      onClick={() => removeMutation.mutate(p.id)}
                    >
                      Eliminar
                    </button>
                  </td>
                </tr>
              ))}
              {prices.length === 0 && (
                <tr>
                  <td colSpan={5} className="py-4 text-slate-500">
                    No hay precios registrados con este filtro.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
