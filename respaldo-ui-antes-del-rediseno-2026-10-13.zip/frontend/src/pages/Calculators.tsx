import { useState } from 'react';
import CalculatorPanel, {
  type CalculatorRunFn,
  type NumberField,
} from '../components/calculators/CalculatorPanel';
import {
  calculatorsApi,
  type BrickInput,
  type CalculatorId,
  type ConcreteInput,
  type MortarInput,
} from '../services/calculators';

interface Tab {
  id: CalculatorId;
  label: string;
  description: string;
  fields: NumberField[];
  run: CalculatorRunFn;
}

const TABS: Tab[] = [
  {
    id: 'concrete',
    label: 'Hormigón',
    description: 'Volumen de una losa o zapata y el cemento, arena y grava necesarios.',
    fields: [
      { name: 'length', label: 'Largo', unit: 'm' },
      { name: 'width', label: 'Ancho', unit: 'm' },
      { name: 'height', label: 'Espesor', unit: 'm', placeholder: '0.15' },
    ],
    run: (v) => calculatorsApi.concrete(v as unknown as ConcreteInput),
  },
  {
    id: 'brick',
    label: 'Mampostería',
    description: 'Ladrillos y mortero de pega para un muro.',
    fields: [
      { name: 'width', label: 'Ancho del muro', unit: 'm' },
      { name: 'height', label: 'Alto del muro', unit: 'm' },
    ],
    run: (v) => calculatorsApi.brick(v as unknown as BrickInput),
  },
  {
    id: 'mortar',
    label: 'Mortero',
    description: 'Mortero de pega o revoque: cemento y arena.',
    fields: [
      { name: 'area', label: 'Área', unit: 'm²' },
      { name: 'thickness', label: 'Espesor', unit: 'cm', placeholder: '2' },
    ],
    run: (v) => calculatorsApi.mortar(v as unknown as MortarInput),
  },
];

export default function Calculators() {
  const [active, setActive] = useState<CalculatorId>('concrete');
  const tab = TABS.find((t) => t.id === active)!;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-slate-900">Calculadoras</h1>
        <p className="mt-2 text-slate-600">
          Calcula materiales con precios de proveedores locales de Nariño.
        </p>
      </div>

      <div className="flex flex-wrap gap-2">
        {TABS.map((t) => (
          <button
            key={t.id}
            type="button"
            onClick={() => setActive(t.id)}
            className={`rounded-md px-4 py-2 text-sm font-medium transition ${
              t.id === active
                ? 'bg-orange-600 text-white'
                : 'bg-white text-slate-700 shadow-sm hover:bg-slate-100'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      <p className="text-slate-600">{tab.description}</p>

      {/* La key fuerza a reiniciar el formulario y el resultado al cambiar de pestaña */}
      <CalculatorPanel key={tab.id} calculatorId={tab.id} fields={tab.fields} run={tab.run} />
    </div>
  );
}
