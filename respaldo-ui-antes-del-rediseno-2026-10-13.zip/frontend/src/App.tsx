import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { Toaster } from 'react-hot-toast';
import { BrowserRouter as Router, Navigate, Route, Routes } from 'react-router-dom';
import AdminRoute from '@components/AdminRoute';
import Layout from '@components/Layout';
import ProtectedRoute from '@components/ProtectedRoute';
import { AuthProvider } from '@context/AuthContext';
import AdminLayout from '@pages/Admin/AdminLayout';
import AdminMaterials from '@pages/Admin/Materials';
import AdminPrices from '@pages/Admin/Prices';
import AdminProviders from '@pages/Admin/Providers';
import AdminUsers from '@pages/Admin/Users';
import ForgotPassword from '@pages/Auth/ForgotPassword';
import Login from '@pages/Auth/Login';
import Register from '@pages/Auth/Register';
import ResetPassword from '@pages/Auth/ResetPassword';
import Calculators from '@pages/Calculators';
import Dashboard from '@pages/Dashboard';
import Home from '@pages/Home';
import ProjectDetail from '@pages/ProjectDetail';
import Projects from '@pages/Projects';
import Providers from '@pages/Providers';
import './App.css';

const queryClient = new QueryClient({
  defaultOptions: { queries: { staleTime: 1000 * 60 * 5, retry: 1 } },
});

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <Router>
        <AuthProvider>
          <Routes>
            {/* Públicas */}
            <Route path="/" element={<Home />} />
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />
            <Route path="/forgot-password" element={<ForgotPassword />} />
            <Route path="/reset-password" element={<ResetPassword />} />

            {/* Con navegación: calculadoras es pública (HU-02.10); el resto exige sesión */}
            <Route element={<Layout />}>
              <Route path="/calculators" element={<Calculators />} />
              <Route element={<ProtectedRoute />}>
                <Route path="/dashboard" element={<Dashboard />} />
                <Route path="/projects" element={<Projects />} />
                <Route path="/projects/:projectId" element={<ProjectDetail />} />
                <Route path="/providers" element={<Providers />} />
              </Route>
              <Route path="/admin" element={<AdminRoute />}>
                <Route element={<AdminLayout />}>
                  <Route index element={<Navigate to="/admin/materials" replace />} />
                  <Route path="materials" element={<AdminMaterials />} />
                  <Route path="prices" element={<AdminPrices />} />
                  <Route path="providers" element={<AdminProviders />} />
                  <Route path="users" element={<AdminUsers />} />
                </Route>
              </Route>
            </Route>
          </Routes>
          {/* bottom-right: top-right queda debajo del botón "Salir" del header y
              puede bloquear el clic mientras el toast está visible (~4s). */}
          <Toaster position="bottom-right" />
        </AuthProvider>
      </Router>
    </QueryClientProvider>
  );
}

export default App;
