import { Link, NavLink, Outlet, useNavigate } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';

const navItems = [
  { to: '/dashboard', label: 'Dashboard' },
  { to: '/calculators', label: 'Calculadoras' },
  { to: '/projects', label: 'Proyectos' },
  { to: '/providers', label: 'Proveedores' },
];

export default function Layout() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = async () => {
    await logout();
    navigate('/login', { replace: true });
  };

  const items = user?.role === 'admin' ? [...navItems, { to: '/admin', label: 'Admin' }] : navItems;

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900">
      <header className="navbar border-b border-slate-200">
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-6 py-4">
          <NavLink to="/dashboard" className="text-xl font-bold text-orange-600">
            ConstruApp Nariño
          </NavLink>

          <nav className="flex flex-wrap items-center gap-2">
            {items.map((item) => (
              <NavLink
                key={item.to}
                to={item.to}
                className={({ isActive }) =>
                  `rounded-md px-3 py-2 text-sm font-medium transition ${
                    isActive
                      ? 'bg-orange-100 text-orange-700'
                      : 'text-slate-700 hover:bg-slate-100'
                  }`
                }
              >
                {item.label}
              </NavLink>
            ))}
          </nav>

          <div className="flex items-center gap-3">
            {user ? (
              <>
                <span className="hidden text-sm text-slate-500 sm:inline">
                  {user.name}
                  {user.role === 'admin' && (
                    <span className="ml-2 rounded bg-slate-800 px-1.5 py-0.5 text-xs text-white">
                      admin
                    </span>
                  )}
                </span>
                <button type="button" onClick={handleLogout} className="btn-secondary">
                  Salir
                </button>
              </>
            ) : (
              <Link to="/login" className="btn-primary">
                Iniciar sesión
              </Link>
            )}
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-7xl px-6 py-8">
        <Outlet />
      </main>
    </div>
  );
}
