import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import type { CreateProjectInput, Project } from '../../services/projects';

const schema = z.object({
  name: z.string().trim().min(2, 'Ingresa un nombre').max(160),
  location: z.string().trim().max(160).optional().or(z.literal('')),
  description: z.string().trim().max(2000).optional().or(z.literal('')),
  budget: z.coerce.number().positive('Debe ser mayor a 0').optional().or(z.literal('')),
});
type FormValues = z.infer<typeof schema>;

interface EditProjectFormProps {
  project: Project;
  onSubmit: (changes: Partial<CreateProjectInput>) => void;
  onCancel: () => void;
  submitting: boolean;
}

export default function EditProjectForm({
  project,
  onSubmit,
  onCancel,
  submitting,
}: EditProjectFormProps) {
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: {
      name: project.name,
      location: project.location ?? '',
      description: project.description ?? '',
      budget: project.budget ?? undefined,
    },
  });

  const submit = (values: FormValues) => {
    onSubmit({
      name: values.name,
      location: values.location || undefined,
      description: values.description || undefined,
      budget: values.budget ? Number(values.budget) : undefined,
    });
  };

  return (
    <form className="card grid gap-4 sm:grid-cols-2" onSubmit={handleSubmit(submit)} noValidate>
      <div>
        <label className="mb-1 block text-sm font-medium text-slate-700" htmlFor="edit-name">
          Nombre
        </label>
        <input id="edit-name" className="input-field" {...register('name')} />
        {errors.name && <p className="mt-1 text-sm text-red-600">{errors.name.message}</p>}
      </div>
      <div>
        <label className="mb-1 block text-sm font-medium text-slate-700" htmlFor="edit-location">
          Ubicación
        </label>
        <input id="edit-location" className="input-field" {...register('location')} />
      </div>
      <div>
        <label className="mb-1 block text-sm font-medium text-slate-700" htmlFor="edit-budget">
          Presupuesto objetivo (COP)
        </label>
        <input
          id="edit-budget"
          type="number"
          step="any"
          className="input-field"
          {...register('budget')}
        />
        {errors.budget && <p className="mt-1 text-sm text-red-600">{errors.budget.message}</p>}
      </div>
      <div className="sm:col-span-2">
        <label className="mb-1 block text-sm font-medium text-slate-700" htmlFor="edit-description">
          Descripción
        </label>
        <textarea
          id="edit-description"
          className="input-field"
          rows={2}
          {...register('description')}
        />
      </div>
      <div className="flex gap-3 sm:col-span-2">
        <button type="submit" className="btn-primary" disabled={submitting}>
          {submitting ? 'Guardando…' : 'Guardar cambios'}
        </button>
        <button type="button" className="btn-secondary" onClick={onCancel}>
          Cancelar
        </button>
      </div>
    </form>
  );
}
