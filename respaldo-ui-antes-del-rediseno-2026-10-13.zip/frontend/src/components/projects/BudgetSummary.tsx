import type { BudgetSummary as BudgetSummaryData } from '../../services/projects';
import { formatCOP } from '../../utils/format';

export default function BudgetSummary({ summary }: { summary: BudgetSummaryData }) {
  const pct = summary.budgetUsedPct !== null ? Math.min(summary.budgetUsedPct, 100) : null;

  return (
    <div className="space-y-2">
      <div className="flex flex-wrap items-baseline justify-between gap-2">
        <span className="text-sm text-slate-500">
          {summary.totalCalculations} cálculo{summary.totalCalculations === 1 ? '' : 's'} · Costo
          estimado
        </span>
        <span className="text-lg font-bold text-slate-900">{formatCOP(summary.totalCost)}</span>
      </div>

      {summary.budget !== null && (
        <>
          <div className="h-2.5 w-full overflow-hidden rounded-full bg-slate-200">
            <div
              className={`h-full rounded-full transition-all ${
                summary.overBudget ? 'bg-red-500' : 'bg-orange-500'
              }`}
              style={{ width: `${pct ?? 0}%` }}
            />
          </div>
          <div className="flex flex-wrap justify-between gap-2 text-sm">
            <span className={summary.overBudget ? 'font-medium text-red-600' : 'text-slate-500'}>
              {summary.budgetUsedPct}% del presupuesto ({formatCOP(summary.budget)})
              {summary.overBudget && ' — superado'}
            </span>
            <span className="text-slate-500">
              {summary.budgetRemaining !== null && summary.budgetRemaining >= 0
                ? `Quedan ${formatCOP(summary.budgetRemaining)}`
                : `Exceso: ${formatCOP(Math.abs(summary.budgetRemaining ?? 0))}`}
            </span>
          </div>
        </>
      )}
    </div>
  );
}
