import type { ProjectStatus } from '../../services/projects';

const LABELS: Record<ProjectStatus, string> = {
  planning: 'Planificación',
  'in-progress': 'En progreso',
  finished: 'Finalizado',
};

const STYLES: Record<ProjectStatus, string> = {
  planning: 'bg-slate-100 text-slate-700',
  'in-progress': 'bg-blue-100 text-blue-700',
  finished: 'bg-emerald-100 text-emerald-700',
};

export default function StatusBadge({ status }: { status: ProjectStatus }) {
  return (
    <span className={`rounded-full px-2.5 py-1 text-xs font-medium ${STYLES[status]}`}>
      {LABELS[status]}
    </span>
  );
}
