import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import type { CreateProjectInput } from '../../services/projects';

const schema = z
  .object({
    name: z.string().trim().min(2, 'Ingresa un nombre').max(160),
    location: z.string().trim().max(160).optional().or(z.literal('')),
    description: z.string().trim().max(2000).optional().or(z.literal('')),
    budget: z.coerce.number().positive('Debe ser mayor a 0').optional().or(z.literal('')),
    startDate: z.string().optional().or(z.literal('')),
    endDate: z.string().optional().or(z.literal('')),
  })
  .refine((v) => !v.startDate || !v.endDate || v.endDate >= v.startDate, {
    message: 'La fecha de fin debe ser posterior a la de inicio',
    path: ['endDate'],
  });

type FormValues = z.infer<typeof schema>;

interface ProjectFormProps {
  onSubmit: (input: CreateProjectInput) => void;
  onCancel: () => void;
  submitting: boolean;
}

export default function ProjectForm({ onSubmit, onCancel, submitting }: ProjectFormProps) {
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<FormValues>({ resolver: zodResolver(schema) });

  const submit = (values: FormValues) => {
    const input: CreateProjectInput = { name: values.name };
    if (values.location) input.location = values.location;
    if (values.description) input.description = values.description;
    if (values.budget) input.budget = Number(values.budget);
    if (values.startDate) input.startDate = values.startDate;
    if (values.endDate) input.endDate = values.endDate;
    onSubmit(input);
  };

  return (
    <form className="card grid gap-4 sm:grid-cols-2" onSubmit={handleSubmit(submit)} noValidate>
      <div className="sm:col-span-2">
        <label className="mb-1 block text-sm font-medium text-slate-700" htmlFor="name">
          Nombre del proyecto
        </label>
        <input
          id="name"
          className="input-field"
          placeholder="Casa en Pasto"
          {...register('name')}
        />
        {errors.name && <p className="mt-1 text-sm text-red-600">{errors.name.message}</p>}
      </div>

      <div>
        <label className="mb-1 block text-sm font-medium text-slate-700" htmlFor="location">
          Ubicación
        </label>
        <input
          id="location"
          className="input-field"
          placeholder="Pasto, Nariño"
          {...register('location')}
        />
      </div>

      <div>
        <label className="mb-1 block text-sm font-medium text-slate-700" htmlFor="budget">
          Presupuesto objetivo (COP)
        </label>
        <input id="budget" type="number" step="any" className="input-field" {...register('budget')} />
        {errors.budget && <p className="mt-1 text-sm text-red-600">{errors.budget.message}</p>}
      </div>

      <div>
        <label className="mb-1 block text-sm font-medium text-slate-700" htmlFor="startDate">
          Fecha de inicio
        </label>
        <input id="startDate" type="date" className="input-field" {...register('startDate')} />
      </div>
      <div>
        <label className="mb-1 block text-sm font-medium text-slate-700" htmlFor="endDate">
          Fecha de fin
        </label>
        <input id="endDate" type="date" className="input-field" {...register('endDate')} />
        {errors.endDate && <p className="mt-1 text-sm text-red-600">{errors.endDate.message}</p>}
      </div>

      <div className="sm:col-span-2">
        <label className="mb-1 block text-sm font-medium text-slate-700" htmlFor="description">
          Descripción
        </label>
        <textarea id="description" className="input-field" rows={2} {...register('description')} />
      </div>

      <div className="flex gap-3 sm:col-span-2">
        <button type="submit" className="btn-primary" disabled={submitting}>
          {submitting ? 'Creando…' : 'Crear proyecto'}
        </button>
        <button type="button" className="btn-secondary" onClick={onCancel}>
          Cancelar
        </button>
      </div>
    </form>
  );
}
