import { useState } from 'react';
import { Link } from 'react-router-dom';
import type { CalculationResult } from '../../services/calculators';
import type { ProjectListItem } from '../../services/projects';
import { formatCOP, formatQty } from '../../utils/format';

interface ResultPanelProps {
  result: CalculationResult;
  projects: ProjectListItem[] | undefined;
  isLoggedIn: boolean;
  onSave: (projectId: string) => void;
  saving: boolean;
}

export default function ResultPanel({
  result,
  projects,
  isLoggedIn,
  onSave,
  saving,
}: ResultPanelProps) {
  const [projectId, setProjectId] = useState('');

  return (
    <div className="card animate-fadeIn space-y-4">
      <div className="flex flex-wrap items-baseline justify-between gap-2">
        <h2 className="text-xl font-semibold text-slate-800">
          Resultado — {formatQty(result.quantity)} {result.unit}
        </h2>
        <span className="text-sm text-slate-500">
          Desperdicio aplicado: {result.wastePct}%
        </span>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-left text-sm">
          <thead>
            <tr className="border-b border-slate-200 text-slate-500">
              <th className="py-2 pr-4">Material</th>
              <th className="py-2 pr-4">Cantidad</th>
              <th className="py-2 pr-4">Precio unitario</th>
              <th className="py-2 pr-4">Subtotal</th>
              <th className="py-2">Proveedor</th>
            </tr>
          </thead>
          <tbody>
            {result.materials.map((m) => (
              <tr key={m.role} className="border-b border-slate-100 last:border-0">
                <td className="py-2 pr-4 font-medium text-slate-800">{m.name}</td>
                <td className="py-2 pr-4">
                  {formatQty(m.quantity)} {m.unit}
                </td>
                <td className="py-2 pr-4">{formatCOP(m.pricePerUnit)}</td>
                <td className="py-2 pr-4">{formatCOP(m.totalPrice)}</td>
                <td className="py-2 text-slate-600">{m.provider?.name ?? 'Sin precio registrado'}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {result.missingPrices.length > 0 && (
        <p className="rounded-md bg-amber-50 px-3 py-2 text-sm text-amber-800">
          Faltan precios en el catálogo para: {result.missingPrices.join(', ')}. El total no los
          incluye.
        </p>
      )}

      <div className="flex items-center justify-between border-t border-slate-200 pt-3">
        <span className="text-lg font-bold text-slate-900">Total: {formatCOP(result.totalCost)}</span>
        <span className="text-xs text-slate-400">
          {new Date(result.timestamp).toLocaleString('es-CO')}
        </span>
      </div>

      {isLoggedIn ? (
        <div className="flex flex-wrap items-center gap-3 border-t border-slate-200 pt-4">
          <select
            className="input-field max-w-xs"
            value={projectId}
            onChange={(e) => setProjectId(e.target.value)}
          >
            <option value="">Elige un proyecto…</option>
            {projects?.map((p) => (
              <option key={p.id} value={p.id}>
                {p.name}
              </option>
            ))}
          </select>
          <button
            type="button"
            className="btn-secondary"
            disabled={!projectId || saving}
            onClick={() => onSave(projectId)}
          >
            {saving ? 'Guardando…' : 'Guardar en proyecto'}
          </button>
          {projects?.length === 0 && (
            <span className="text-sm text-slate-500">
              No tienes proyectos aún. <Link to="/projects" className="underline">Crea uno</Link>.
            </span>
          )}
        </div>
      ) : (
        <p className="border-t border-slate-200 pt-4 text-sm text-slate-500">
          <Link to="/login" className="font-medium text-orange-600 hover:underline">
            Inicia sesión
          </Link>{' '}
          para guardar este cálculo en un proyecto.
        </p>
      )}
    </div>
  );
}
