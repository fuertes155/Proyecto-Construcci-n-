import { zodResolver } from '@hookform/resolvers/zod';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useState } from 'react';
import { useForm, type Resolver } from 'react-hook-form';
import toast from 'react-hot-toast';
import { z, type ZodTypeAny } from 'zod';
import { useAuth } from '../../hooks/useAuth';
import { apiErrorMessage } from '../../services/api';
import type { CalculationResult, CalculatorId } from '../../services/calculators';
import { projectsApi } from '../../services/projects';
import ResultPanel from './ResultPanel';

export interface NumberField {
  name: string;
  label: string;
  unit: string;
  placeholder?: string;
}

export type CalculatorRunFn = (values: Record<string, number>) => Promise<CalculationResult>;

interface CalculatorPanelProps {
  calculatorId: CalculatorId;
  fields: NumberField[];
  run: CalculatorRunFn;
}

const MAX_WASTE_PCT = 30;

/**
 * Los campos varían según la calculadora (`fields`), así que el formulario se
 * tipa de forma genérica: un número por campo + `wastePct` opcional. La forma
 * concreta (`ConcreteInput`, `BrickInput`, …) la valida el propio backend.
 */
type FormValues = Record<string, number | undefined>;

export default function CalculatorPanel({ calculatorId, fields, run }: CalculatorPanelProps) {
  const { user } = useAuth();
  const [result, setResult] = useState<CalculationResult | null>(null);
  const [lastInputs, setLastInputs] = useState<Record<string, number> | null>(null);
  const queryClient = useQueryClient();

  const shape: Record<string, ZodTypeAny> = Object.fromEntries(
    fields.map((f) => [
      f.name,
      z.coerce
        .number({ invalid_type_error: `${f.label} es obligatorio` })
        .positive(`${f.label} debe ser mayor a 0`),
    ])
  );
  const schema = z.object({
    ...shape,
    wastePct: z.coerce.number().min(0).max(MAX_WASTE_PCT).optional(),
  });

  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<FormValues>({
    resolver: zodResolver(schema) as Resolver<FormValues>,
    defaultValues: { wastePct: 5 },
  });

  const { data: projectsData } = useQuery({
    queryKey: ['projects'],
    queryFn: projectsApi.list,
    enabled: !!user,
  });

  const saveMutation = useMutation({
    mutationFn: ({ projectId }: { projectId: string }) =>
      projectsApi.addCalculation(projectId, calculatorId, lastInputs ?? {}),
    onSuccess: () => {
      toast.success('Cálculo guardado en el proyecto');
      queryClient.invalidateQueries({ queryKey: ['projects'] });
    },
    onError: (err) => toast.error(apiErrorMessage(err, 'No se pudo guardar el cálculo')),
  });

  const onSubmit = async (values: FormValues) => {
    const { wastePct, ...rest } = values;
    const inputs = { ...rest, ...(wastePct !== undefined ? { wastePct } : {}) } as Record<
      string,
      number
    >;
    try {
      const res = await run(inputs);
      setResult(res);
      setLastInputs(inputs);
    } catch (err) {
      toast.error(apiErrorMessage(err, 'No se pudo calcular'));
    }
  };

  return (
    <div className="space-y-6">
      <form
        className="card grid gap-4 sm:grid-cols-2 lg:grid-cols-4"
        onSubmit={handleSubmit(onSubmit)}
        noValidate
      >
        {fields.map((f) => (
          <div key={f.name}>
            <label className="mb-1 block text-sm font-medium text-slate-700" htmlFor={f.name}>
              {f.label} <span className="text-slate-400">({f.unit})</span>
            </label>
            <input
              id={f.name}
              type="number"
              step="any"
              className="input-field"
              placeholder={f.placeholder}
              {...register(f.name)}
            />
            {errors[f.name] && (
              <p className="mt-1 text-sm text-red-600">{String(errors[f.name]?.message)}</p>
            )}
          </div>
        ))}
        <div>
          <label className="mb-1 block text-sm font-medium text-slate-700" htmlFor="wastePct">
            Desperdicio <span className="text-slate-400">(%)</span>
          </label>
          <input
            id="wastePct"
            type="number"
            step="any"
            className="input-field"
            {...register('wastePct')}
          />
          {errors.wastePct && (
            <p className="mt-1 text-sm text-red-600">{String(errors.wastePct.message)}</p>
          )}
        </div>
        <div className="flex items-end sm:col-span-2 lg:col-span-4">
          <button type="submit" className="btn-primary" disabled={isSubmitting}>
            {isSubmitting ? 'Calculando…' : 'Calcular'}
          </button>
        </div>
      </form>

      {result && (
        <ResultPanel
          result={result}
          projects={projectsData?.projects}
          isLoggedIn={!!user}
          onSave={(projectId) => saveMutation.mutate({ projectId })}
          saving={saveMutation.isPending}
        />
      )}
    </div>
  );
}
